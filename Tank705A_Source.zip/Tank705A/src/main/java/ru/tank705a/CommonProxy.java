package ru.tank705a;
public class CommonProxy { public void registerRenderers() { } }
