package ru.tank705a;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;

import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;
import ru.tank705a.init.ModItems;
import ru.tank705a.init.ModEntities;

@Mod(modid = Tank705AMod.MODID, name = Tank705AMod.NAME, version = Tank705AMod.VERSION)
public class Tank705AMod {
    public static final String MODID = "tank705a";
    public static final String NAME = "Object 705A Tank";
    public static final String VERSION = "1.0.0";
    @SidedProxy(clientSide = "ru.tank705a.client.ClientProxy", serverSide = "ru.tank705a.CommonProxy")
    public static CommonProxy proxy;
    public static final CreativeTabs TAB = new CreativeTabs("tank705a") {
        @Override public ItemStack getTabIconItem() { return new ItemStack(ModItems.TANK_SPAWNER); }
    };

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        ModItems.register();
        ModEntities.register();
        proxy.registerRenderers();
    }
}
