package ru.tank705a.item;

import java.util.List;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.*;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import ru.tank705a.entity.EntityTank705A;

public class ItemTankRemover extends Item {
    public ItemTankRemover() { setMaxStackSize(1); }
    @Override public ActionResult<ItemStack> onItemRightClick(World world, EntityPlayer player, EnumHand hand) {
        ItemStack stack = player.getHeldItem(hand);
        Vec3d look = player.getLookVec();
        Vec3d end = player.getPositionEyes(1.0F).add(look.scale(6.0D));
        AxisAlignedBB area = player.getEntityBoundingBox().expand(look.x * 6, look.y * 6, look.z * 6).grow(1.2D);
        List<EntityTank705A> tanks = world.getEntitiesWithinAABB(EntityTank705A.class, area);
        EntityTank705A closest = null; double best = 36.0D;
        for (EntityTank705A tank : tanks) {
            AxisAlignedBB box = tank.getEntityBoundingBox().grow(0.4D);
            if (box.calculateIntercept(player.getPositionEyes(1.0F), end) != null) {
                double d = player.getDistanceSq(tank); if (d < best) { best = d; closest = tank; }
            }
        }
        if (closest != null) { if (!world.isRemote) closest.setDead(); return new ActionResult<ItemStack>(EnumActionResult.SUCCESS, stack); }
        return new ActionResult<ItemStack>(EnumActionResult.PASS, stack);
    }
}
