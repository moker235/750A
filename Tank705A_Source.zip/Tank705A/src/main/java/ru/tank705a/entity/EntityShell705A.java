package ru.tank705a.entity;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.projectile.EntityThrowable;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.world.World;

public class EntityShell705A extends EntityThrowable {
    public EntityShell705A(World world) { super(world); }
    public EntityShell705A(World world, EntityLivingBase thrower) {
        super(world, thrower);
        setHeading(-Math.sin(Math.toRadians(thrower.rotationYaw)), thrower.getLookVec().y * 0.12D, Math.cos(Math.toRadians(thrower.rotationYaw)), 2.2F, 0.0F);
    }
    @Override protected void onImpact(RayTraceResult result) {
        if (!world.isRemote) { world.createExplosion(this, posX, posY, posZ, 4.0F, true); setDead(); }
    }
}
