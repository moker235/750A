package ru.tank705a.entity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.MoverType;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.world.World;

public class EntityTank705A extends Entity {
    private int fireCooldown = 0;
    public EntityTank705A(World world) { super(world); setSize(1.85F, 1.35F); isImmuneToFire = true; }
    @Override protected void entityInit() { }
    @Override protected void readEntityFromNBT(NBTTagCompound compound) { }
    @Override protected void writeEntityToNBT(NBTTagCompound compound) { }
    @Override public boolean attackEntityFrom(DamageSource source, float amount) { return false; }
    @Override public boolean isEntityInvulnerable(DamageSource source) { return true; }
    @Override public boolean canBePushed() { return false; }
    @Override public void onUpdate() {
        super.onUpdate();
        if (fireCooldown > 0) fireCooldown--;
        if (getControllingPassenger() instanceof EntityPlayer) {
            EntityPlayer rider = (EntityPlayer)getControllingPassenger();
            rotationYaw = rider.rotationYaw;
            if (!world.isRemote) {
                motionX = -Math.sin(Math.toRadians(rotationYaw)) * 0.20D;
                motionZ = Math.cos(Math.toRadians(rotationYaw)) * 0.20D;
                if (rider.isSneaking() && fireCooldown <= 0) { fireShell(rider); fireCooldown = 30; }
            }
        } else { motionX *= 0.7D; motionZ *= 0.7D; }
        if (!world.isRemote) {
            if (!onGround) motionY -= 0.08D; else if (motionY < 0) motionY = 0;
            move(MoverType.SELF, motionX, motionY, motionZ);
        }
    }
    private void fireShell(EntityPlayer rider) {
        EntityShell705A shell = new EntityShell705A(world, rider);
        shell.setPosition(posX - Math.sin(Math.toRadians(rotationYaw))*1.7D, posY + 1.0D, posZ + Math.cos(Math.toRadians(rotationYaw))*1.7D);
        world.spawnEntity(shell);
    }
    @Override public boolean processInitialInteract(EntityPlayer player, EnumHand hand) {
        if (getPassengers().isEmpty()) { if (!world.isRemote) player.startRiding(this); return true; }
        return getControllingPassenger() == player;
    }
    @Override public double getMountedYOffset() { return 0.65D; }
    @Override public boolean canBeCollidedWith() { return true; }
    @Override public boolean canBeRidden(Entity entity) { return getPassengers().isEmpty(); }
    @Override public void fall(float distance, float damageMultiplier) { }
}
