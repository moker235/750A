package ru.tank705a.client;

import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;
import ru.tank705a.Tank705AMod;
import ru.tank705a.entity.EntityTank705A;

public class RenderTank705A extends Render<EntityTank705A> {
    private final ModelTank705A model = new ModelTank705A();
    private static final ResourceLocation TEXTURE = new ResourceLocation(Tank705AMod.MODID, "textures/entity/tank_705a.png");
    public RenderTank705A(RenderManager manager) { super(manager); shadowSize = 0.9F; }
    @Override public void doRender(EntityTank705A entity, double x, double y, double z, float entityYaw, float partialTicks) {
        net.minecraft.client.renderer.GlStateManager.pushMatrix();
        net.minecraft.client.renderer.GlStateManager.translate(x, y + 1.5D, z);
        net.minecraft.client.renderer.GlStateManager.rotate(180F - entityYaw, 0F, 1F, 0F);
        bindEntityTexture(entity);
        model.render(entity, 0, 0, entity.ticksExisted + partialTicks, 0, 0, 0.0625F);
        net.minecraft.client.renderer.GlStateManager.popMatrix();
        super.doRender(entity, x, y, z, entityYaw, partialTicks);
    }
    @Override protected ResourceLocation getEntityTexture(EntityTank705A entity) { return TEXTURE; }
}
