package ru.tank705a.client;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

public class ModelTank705A extends ModelBase {
    private final ModelRenderer hull, turret, barrel, leftTrack, rightTrack;
    public ModelTank705A() {
        textureWidth = 128; textureHeight = 64;
        hull = new ModelRenderer(this, 0, 0); hull.addBox(-9F, -4F, -13F, 18, 7, 26); hull.setRotationPoint(0F, 16F, 0F);
        turret = new ModelRenderer(this, 0, 34); turret.addBox(-6F, -3F, -6F, 12, 4, 13); turret.setRotationPoint(0F, 10F, 0F);
        barrel = new ModelRenderer(this, 54, 34); barrel.addBox(-1.4F, -1.4F, -13F, 2, 2, 14); barrel.setRotationPoint(0F, 11F, -4F);
        leftTrack = new ModelRenderer(this, 72, 0); leftTrack.addBox(-10F, -3F, -13F, 3, 8, 26); leftTrack.setRotationPoint(0F, 18F, 0F);
        rightTrack = new ModelRenderer(this, 72, 0); rightTrack.addBox(7F, -3F, -13F, 3, 8, 26); rightTrack.setRotationPoint(0F, 18F, 0F);
    }
    @Override public void render(Entity entity, float limbSwing, float limbSwingAmount, float age, float yaw, float pitch, float scale) {
        hull.render(scale); turret.render(scale); barrel.render(scale); leftTrack.render(scale); rightTrack.render(scale);
    }
}
