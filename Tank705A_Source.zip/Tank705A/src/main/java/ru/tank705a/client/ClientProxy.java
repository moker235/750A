package ru.tank705a.client;

import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import ru.tank705a.CommonProxy;
import ru.tank705a.init.ModItems;
import ru.tank705a.entity.EntityTank705A;

public class ClientProxy extends CommonProxy {
    @Override public void registerRenderers() {
        ModelLoader.setCustomModelResourceLocation(ModItems.TANK_SPAWNER, 0, new ModelResourceLocation(ModItems.TANK_SPAWNER.getRegistryName(), "inventory"));
        ModelLoader.setCustomModelResourceLocation(ModItems.TANK_REMOVER, 0, new ModelResourceLocation(ModItems.TANK_REMOVER.getRegistryName(), "inventory"));
        RenderingRegistry.registerEntityRenderingHandler(EntityTank705A.class, RenderTank705A::new);
    }
}
