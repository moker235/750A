package ru.tank705a.init;

import net.minecraft.item.Item;
import net.minecraftforge.fml.common.registry.GameRegistry;
import ru.tank705a.Tank705AMod;
import ru.tank705a.item.ItemTankRemover;
import ru.tank705a.item.ItemTankSpawner;

public final class ModItems {
    public static Item TANK_SPAWNER;
    public static Item TANK_REMOVER;
    public static void register() {
        TANK_SPAWNER = new ItemTankSpawner().setRegistryName(Tank705AMod.MODID, "tank_spawner").setUnlocalizedName(Tank705AMod.MODID + ".tank_spawner").setCreativeTab(Tank705AMod.TAB);
        TANK_REMOVER = new ItemTankRemover().setRegistryName(Tank705AMod.MODID, "tank_remover").setUnlocalizedName(Tank705AMod.MODID + ".tank_remover").setCreativeTab(Tank705AMod.TAB);
        GameRegistry.findRegistry(Item.class).register(TANK_SPAWNER);
        GameRegistry.findRegistry(Item.class).register(TANK_REMOVER);
    }
}
