package ru.tank705a.init;

import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.registry.EntityRegistry;
import ru.tank705a.Tank705AMod;
import ru.tank705a.entity.EntityShell705A;
import ru.tank705a.entity.EntityTank705A;

public final class ModEntities {
    public static void register() {
        EntityRegistry.registerModEntity(new ResourceLocation(Tank705AMod.MODID, "tank_705a"), EntityTank705A.class, "tank_705a", 1, Tank705AMod.MODID, 80, 3, true);
        EntityRegistry.registerModEntity(new ResourceLocation(Tank705AMod.MODID, "shell_705a"), EntityShell705A.class, "shell_705a", 2, Tank705AMod.MODID, 80, 3, true);
    }
}
